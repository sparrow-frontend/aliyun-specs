//
//  UTDIDPublic.h
//  UTDID
//
//  Created by ljianfeng on 2019/8/1.
//  Copyright © 2019 Alvin. All rights reserved.
//

#ifndef UTDID_h
#define UTDID_h
#import <UTDID/UTDevice.h>
#import <UTDID/AidProtocol.h>
#endif /* UTDIDPublic_h */
